jQuery(function($) {
	$.colorpicker.regional['fr'] = {
		done:            'Valider',
		none:            'Aucune couleur',
		revert:          'Couleur',
		button:          'Couleur',
		title:           'Choisir une couleur',
		transparent:     'Transparent',
		hueShort:        'T',
		saturationShort: 'S',
		valueShort:      'V',
		redShort:        'R',
		greenShort:      'V',
		blueShort:       'B',
		alphaShort:      'A'
	};
});
