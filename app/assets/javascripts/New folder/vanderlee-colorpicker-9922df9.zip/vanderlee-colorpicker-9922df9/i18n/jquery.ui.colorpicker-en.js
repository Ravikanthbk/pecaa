jQuery(function($) {
	$.colorpicker.regional['en'] = {
		done:			'Done',
		none:			'None',
		revert:			'Color',
		button:			'Color',
		title:			'Pick a color',
		transparent:	'Transparent',
		hueShort:		'H',
		saturationShort:'S',
		valueShort:		'V',
		redShort:		'R',
		greenShort:		'G',
		blueShort:		'B',
		alphaShort:		'A'
	};
});