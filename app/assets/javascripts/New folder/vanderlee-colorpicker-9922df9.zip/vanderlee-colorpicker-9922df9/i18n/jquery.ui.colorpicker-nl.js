jQuery(function($) {
	$.colorpicker.regional['nl'] = {
		done:			'Sluiten',
		none:			'Geen',
		revert:			'Kleur',
		button:			'Kleur',
		title:			'Kies een kleur',
		transparent:	'Transparant',
		hueShort:		'H',
		saturationShort:'S',
		valueShort:		'V',
		redShort:		'R',
		greenShort:		'G',
		blueShort:		'B',
		alphaShort:		'A'
	};
});